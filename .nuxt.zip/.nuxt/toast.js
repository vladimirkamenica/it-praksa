import Vue from 'vue'
import Toasted from 'vue-toasted'

Vue.use(Toasted, {"position":"top-right","duration":5000,"keepOnHover":true,"fullWidth":false,"fitToScreen":true,"className":"vue-toast-custom","closeOnSwipe":true})

const globals = [{"name":"my-error","message":"Oops...Something went wrong","options":{"type":"error"}}]
if(globals) {
  globals.forEach(global => {
    Vue.toasted.register(global.name, global.message, global.options)
  })
}

export default function (ctx, inject) {
  inject('toast', Vue.toasted)
}
