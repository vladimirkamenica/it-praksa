import moment from 'moment'

import 'moment/locale/sr'

moment.locale('sr')

export default (ctx, inject) => {
  ctx.$moment = moment
  inject('moment', moment)
}
