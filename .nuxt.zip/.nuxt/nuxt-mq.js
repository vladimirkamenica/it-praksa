import Vue from 'vue'
import VueMq from 'vue-mq'

Vue.use(VueMq, {"defaultBreakpoint":"xl","breakpoints":{"iphone_5":325,"sm":450,"md":768,"lg":992,"xl":1300,"xxl":1400}})
