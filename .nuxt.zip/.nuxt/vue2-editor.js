import Vue from "vue";
import Vue2Editor from "vue2-editor";

Vue.use(Vue2Editor);
