const middleware = {}

middleware['ads'] = require('..\\middleware\\ads.js')
middleware['ads'] = middleware['ads'].default || middleware['ads']

middleware['auth'] = require('..\\middleware\\auth.js')
middleware['auth'] = middleware['auth'].default || middleware['auth']

middleware['authuser'] = require('..\\middleware\\authuser.js')
middleware['authuser'] = middleware['authuser'].default || middleware['authuser']

middleware['news'] = require('..\\middleware\\news.js')
middleware['news'] = middleware['news'].default || middleware['news']

middleware['redirect'] = require('..\\middleware\\redirect.js')
middleware['redirect'] = middleware['redirect'].default || middleware['redirect']

middleware['roles'] = require('..\\middleware\\roles.js')
middleware['roles'] = middleware['roles'].default || middleware['roles']

middleware['videos'] = require('..\\middleware\\videos.js')
middleware['videos'] = middleware['videos'].default || middleware['videos']

export default middleware
