import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

import _ad78ddba from '..\\pages\\it-vesti\\index.vue'
import _dc71c370 from '..\\pages\\kontakt.vue'
import _1106a611 from '..\\pages\\login.vue'
import _edbfdb64 from '..\\pages\\marketing.vue'
import _38155aa6 from '..\\pages\\o-nama.vue'
import _89c3cfe8 from '..\\pages\\privatnost.vue'
import _4d05911c from '..\\pages\\uslovi.vue'
import _7099e54d from '..\\pages\\usluge.vue'
import _6d22b123 from '..\\pages\\cms\\myads.vue'
import _e2977926 from '..\\pages\\cms\\myadstopage.vue'
import _2775eac0 from '..\\pages\\cms\\myregister.vue'
import _4bdfcb90 from '..\\pages\\cms\\newspaper.vue'
import _0ca1e627 from '..\\pages\\cms\\role.vue'
import _74b212cc from '..\\pages\\cms\\video.vue'
import _a408f4ac from '..\\pages\\it-vesti\\_title\\index.vue'
import _475f02fa from '..\\pages\\index.vue'
import _66d83c7c from '..\\pages\\_categoryvideo\\index.vue'
import _4d006ffa from '..\\pages\\_categoryvideo\\_title\\index.vue'

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/it-vesti",
    component: _ad78ddba,
    name: "it-vesti"
  }, {
    path: "/kontakt",
    component: _dc71c370,
    name: "kontakt"
  }, {
    path: "/login",
    component: _1106a611,
    name: "login"
  }, {
    path: "/marketing",
    component: _edbfdb64,
    name: "marketing"
  }, {
    path: "/o-nama",
    component: _38155aa6,
    name: "o-nama"
  }, {
    path: "/privatnost",
    component: _89c3cfe8,
    name: "privatnost"
  }, {
    path: "/uslovi",
    component: _4d05911c,
    name: "uslovi"
  }, {
    path: "/usluge",
    component: _7099e54d,
    name: "usluge"
  }, {
    path: "/cms/myads",
    component: _6d22b123,
    name: "cms-myads"
  }, {
    path: "/cms/myadstopage",
    component: _e2977926,
    name: "cms-myadstopage"
  }, {
    path: "/cms/myregister",
    component: _2775eac0,
    name: "cms-myregister"
  }, {
    path: "/cms/newspaper",
    component: _4bdfcb90,
    name: "cms-newspaper"
  }, {
    path: "/cms/role",
    component: _0ca1e627,
    name: "cms-role"
  }, {
    path: "/cms/video",
    component: _74b212cc,
    name: "cms-video"
  }, {
    path: "/it-vesti/:title",
    component: _a408f4ac,
    name: "it-vesti-title"
  }, {
    path: "/",
    component: _475f02fa,
    name: "index"
  }, {
    path: "/:categoryvideo",
    component: _66d83c7c,
    name: "categoryvideo"
  }, {
    path: "/:categoryvideo/:title",
    component: _4d006ffa,
    name: "categoryvideo-title"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
